#pragma once

#ifndef FASTFETCH_INCLUDED_osascript
#define FASTFETCH_INCLUDED_osascript

#include "fastfetch.h"

bool ffOsascript(const char* input, FFstrbuf* result);

#endif
