#include "fastfetch.h"
#include "common/printing.h"

void ffPrintBreak(FFinstance* instance)
{
    ffLogoPrintLine(instance);
    putchar('\n');
}
