#pragma once

#ifndef FF_INCLUDED_detection_cpu_cpuUsage
#define FF_INCLUDED_detection_cpu_cpuUsage

const char* ffGetCpuUsageInfo(long* inUseAll, long* totalAll);

#endif
