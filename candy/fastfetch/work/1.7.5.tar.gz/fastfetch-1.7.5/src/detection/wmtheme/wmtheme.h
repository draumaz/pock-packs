#pragma once

#ifndef FASTFETCH_INCLUDED_detection_wmtheme
#define FASTFETCH_INCLUDED_detection_wmtheme

bool ffDetectWmTheme(FFinstance* instance, FFstrbuf* themeOrError);

#endif
