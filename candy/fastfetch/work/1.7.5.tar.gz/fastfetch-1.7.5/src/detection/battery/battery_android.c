#include "fastfetch.h"
#include "common/io.h"
#include "battery.h"

#include <dirent.h>

const char* ffDetectBatteryImpl(FFinstance* instance, FFlist* results) {
    FF_UNUSED(instance, results)
    return "Unimplemented";
}
