#pragma once

#ifndef FF_INCLUDED_detection_qt
#define FF_INCLUDED_detection_qt

#include "fastfetch.h"

typedef struct FFQtResult
{
    FFstrbuf widgetStyle;
    FFstrbuf colorScheme;
    FFstrbuf icons;
    FFstrbuf font;
} FFQtResult;

const FFQtResult* ffDetectQt(const FFinstance* instance);

#endif
