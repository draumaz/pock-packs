#include "fastfetch.h"

const char* ffDetectPowerAdapterImpl(FFinstance* instance, FFlist* results)
{
    FF_UNUSED(instance, results);
    return "Unimplemented";
}
