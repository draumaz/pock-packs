#pragma once

#ifndef FF_INCLUDED_detection_disk_disk
#define FF_INCLUDED_detection_disk_disk

#include "fastfetch.h"

const char* ffDiskAutodetectFolders(FFinstance* instance, FFlist* folders);

#endif
