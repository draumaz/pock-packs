---
name: Logo request
about: Request a new logo
title: ''
labels: logo request
assignees: ''

---

# OS
```
paste content of /etc/os-release here. If this file doesn't exist, describe a way to identify the distro.
```

# Ascii
```
paste ascii art here. If you leave this empty, i will try to find the logo myself.
```
