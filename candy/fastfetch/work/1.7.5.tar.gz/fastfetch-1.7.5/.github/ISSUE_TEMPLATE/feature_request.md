---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

# Current state:

# Wanted state:

# Why the change is sensible:
